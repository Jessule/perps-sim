# Grok Bot PERPS — paper trading SIMULADO (cripto + acciones)

⚠️ **Cuenta 100% ficticia.** No usa dinero real ni Trading 212. Precios reales públicos (Binance → Coinbase de respaldo; acciones con yfinance), operaciones inventadas.

## Qué hace
- 5.000 € iniciales, importes en € con $ entre paréntesis.
- Activos: BTC, ETH, SOL, XRP, AVAX, SUI + NVDA, AAPL, MSFT, TSLA, AMZN, META, GOOGL, AAOI, SNDK.
- Perpetuos LONG/SHORT, apalancamiento **libre de 1x a 40x** elegido por Chief en cada operación.
- Comisión 0,5 % de entrada y 0,5 % de salida sobre el nocional. Liquidación: se pierde todo el margen al tocar el precio de liquidación (mantenimiento 0,5 %).
- Agentes (reglas/indicadores, sin LLM):
  - **Scout**: movimientos fuertes (retorno 1h + volumen).
  - **News**: flujo/catalizador por el cambio 24h.
  - **Sentiment**: Fear & Greed (cripto) / momentum (acciones) + RSI.
  - **Charts**: stop 1,5 ATR, take profit 3 ATR, R/R, tendencia EMA20/50.
  - **Skeptic**: riesgo 1–10, veto con 8 o más. **Anti-FOMO**: sube el riesgo si el precio está a más de 2 ATR de la media 20 o hay un spike grande en 24h.
  - **Chief**: capital en 4 partes; mitad de tamaño con riesgo 6–7; si hay FOMO espera un retroceso en vez de perseguir; elige el apalancamiento según convicción y riesgo, sin dejar que la liquidación quede antes del stop.
- El feed de la app muestra el razonamiento de cada decisión. El estado se guarda en `state.json`.

## Cómo arrancarlo (Windows / PowerShell)
```powershell
cd C:\Users\k00le\Downloads\Memecoin\crypto_perps_app
pip install -r requirements.txt
python run.py
```
Abre http://localhost:8000. Mientras la ventana esté abierta, los bots siguen operando.

## Desde el móvil (misma Wi-Fi)
1. `run.py` muestra la IP del PC al arrancar (o mírala con `ipconfig`, en "Dirección IPv4").
2. En el móvil, abre Chrome y entra en `http://<IP-del-PC>:8000`.
3. Menú ⋮ → **Añadir a pantalla de inicio**.
4. Si no carga, permite Python en el Firewall de Windows (redes privadas).

Reiniciar la cuenta: botón al final de la app, o borra `state.json`.
