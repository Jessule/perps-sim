"""Los 6 agentes como lógica de reglas / indicadores (sin LLM)."""
def ema(xs, n):
    k = 2/(n+1); e = xs[0]
    for x in xs[1:]: e = x*k + e*(1-k)
    return e
def rsi(xs, n=14):
    g = l = 0
    for a, b in zip(xs[-n-1:-1], xs[-n:]):
        d = b-a; g += max(d, 0); l += max(-d, 0)
    return 100 if l == 0 else 100 - 100/(1+g/l)
def atr(c, n=14):
    trs = [max(h-l, abs(h-pc), abs(l-pc)) for (_, h, l, _, _), (_, _, _, pc, _) in zip(c[-n:], c[-n-1:-1])]
    return sum(trs)/len(trs)

def indicators(c, px):
    cl = [x[3] for x in c] + [px]
    vols = [x[4] for x in c]
    n24 = min(len(cl)-1, 288)
    return dict(px=px, atr=atr(c), rsi=rsi(cl), ema20=ema(cl[-60:], 20), ema50=ema(cl[-150:], 50),
                sma20=sum(cl[-20:])/20, ret1h=px/cl[-13]-1, ret24=px/cl[-n24-1]-1,
                volr=(sum(vols[-3:])/3)/max(1e-9, sum(vols[-50:])/50))

def scout(i, stock):
    th = 0.006 if stock else 0.012
    strong = abs(i["ret1h"]) > th or (i["volr"] > 2.5 and abs(i["ret1h"]) > th/2)
    side = "LONG" if i["ret1h"] > 0 else "SHORT"
    return strong, side, f"1h {i['ret1h']*100:+.2f}% · vol x{i['volr']:.1f} " + ("→ movimiento fuerte" if strong else "→ sin señal")

def news(i, side, stock):
    # Sin API de noticias: proxy de régimen/flujo 24h (catalizador probable si el 24h es grande).
    r = i["ret24"]; big = 0.04 if stock else 0.06
    agree = (r > 0) == (side == "LONG")
    score = 1 if agree and abs(r) < big*2 else (-1 if not agree and abs(r) > big else 0)
    return score, f"24h {r*100:+.1f}% " + ("(flujo a favor)" if score > 0 else "(flujo en contra)" if score < 0 else "(neutral)")

def sentiment(i, fng, side, label="Fear&Greed"):
    s = 0
    if side == "LONG": s += 1 if 45 <= fng <= 75 else (-1 if fng > 80 else 0)
    else: s += 1 if fng < 40 else (-1 if fng > 70 else 0)
    if side == "LONG" and i["rsi"] > 75: s -= 1
    if side == "SHORT" and i["rsi"] < 25: s -= 1
    return s, f"{label} {fng} · RSI {i['rsi']:.0f} → {['negativo','neutral','positivo'][max(-1,min(1,s))+1]}"

def charts(i, side):
    a = i["atr"]; px = i["px"]
    trend_ok = (i["ema20"] > i["ema50"]) == (side == "LONG")
    sl = px - 1.5*a if side == "LONG" else px + 1.5*a
    tp = px + 3*a if side == "LONG" else px - 3*a
    rr = abs(tp-px)/abs(px-sl)
    return dict(sl=sl, tp=tp, rr=rr, trend_ok=trend_ok), \
        f"ATR {a:.4g} · SL {sl:.4g} · TP {tp:.4g} · R/R {rr:.1f} · tendencia {'a favor' if trend_ok else 'en contra'}"

def skeptic(i, side, ch, news_s, sent_s, stock):
    r = 3; why = []
    atrp = i["atr"]/i["px"]
    if atrp > (0.006 if stock else 0.01): r += 2; why.append(f"volatilidad alta ({atrp*100:.2f}% ATR)")
    if not ch["trend_ok"]: r += 2; why.append("contra tendencia")
    if news_s < 0: r += 1; why.append("24h en contra")
    if sent_s < 0: r += 1; why.append("sentimiento en contra")
    # Anti-FOMO: movimiento ya extendido
    ext = (i["px"] - i["sma20"])/i["atr"] * (1 if side == "LONG" else -1)
    spike = i["ret24"] * (1 if side == "LONG" else -1) > (0.08 if stock else 0.10)
    fomo = ext > 2 or spike
    if ext > 2: r += 2; why.append(f"anti-FOMO: {ext:.1f} ATR sobre la media 20")
    if spike: r += 2; why.append(f"anti-FOMO: spike 24h {i['ret24']*100:+.1f}%")
    if news_s > 0 and sent_s > 0 and ch["trend_ok"]: r -= 1; why.append("todo alineado")
    r = max(1, min(10, r))
    return r, fomo, f"Riesgo {r}/10" + (" · VETO" if r >= 8 else "") + (": " + ", ".join(why) if why else "")

def chief_leverage(risk, conviction, stop_pct):
    """Chief elige libremente 1x-40x: convicción (0-1) empuja hacia arriba, riesgo de Skeptic hacia abajo,
    y nunca tanto como para que la liquidación quede antes que el stop."""
    base = 1 + 39 * conviction * ((10 - risk) / 9) ** 1.5
    liq_cap = 0.8 / max(stop_pct + 0.01, 1e-6)  # liquidación ≈ 1/lev; dejamos margen sobre el stop + comisiones
    lev = int(max(1, min(40, base, liq_cap)))
    why = f"convicción {conviction:.2f}, riesgo {risk}/10 → {base:.0f}x deseado"
    if liq_cap < base: why += f", limitado a {int(max(1,min(40,liq_cap)))}x para que la liquidación quede más allá del stop"
    return lev, why
