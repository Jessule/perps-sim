"""Datos de mercado públicos (sin API keys). Cripto: Binance -> Coinbase. Acciones: yfinance."""
import time, requests
CRYPTO = ["BTC", "ETH", "SOL", "XRP", "AVAX", "SUI"]
STOCKS = ["NVDA", "AAPL", "MSFT", "TSLA", "AMZN", "META", "GOOGL", "AAOI", "SNDK"]
ASSETS = CRYPTO + STOCKS
S = requests.Session(); S.headers["User-Agent"] = "crypto-perps-sim/1.0"
_cache = {}

def _cached(key, ttl, fn):
    v = _cache.get(key)
    if v and time.time() - v[0] < ttl: return v[1]
    try:
        r = fn(); _cache[key] = (time.time(), r); return r
    except Exception:
        return v[1] if v else None

def _get(url, **kw):
    r = S.get(url, timeout=8, **kw); r.raise_for_status(); return r.json()

def eurusd():
    return _cached("fx", 600, lambda: float(_get("https://api.coinbase.com/v2/exchange-rates?currency=EUR")["data"]["rates"]["USD"])) or 1.10

# ---------- cripto ----------
def _crypto_candles(sym):
    try:
        k = _get(f"https://api.binance.com/api/v3/klines?symbol={sym}USDT&interval=5m&limit=300")
        return [(x[0]//1000, float(x[2]), float(x[3]), float(x[4]), float(x[5])) for x in k]
    except Exception:
        k = _get(f"https://api.exchange.coinbase.com/products/{sym}-USD/candles?granularity=300")
        k = sorted(k)[-300:]  # [t, low, high, open, close, vol]
        return [(x[0], x[2], x[1], x[4], x[5]) for x in k]

def _crypto_price(sym):
    try: return float(_get(f"https://api.binance.com/api/v3/ticker/price?symbol={sym}USDT")["price"])
    except Exception: return float(_get(f"https://api.coinbase.com/v2/prices/{sym}-USD/spot")["data"]["amount"])

def _crypto_book(sym):
    try:
        b = _get(f"https://api.binance.com/api/v3/depth?symbol={sym}USDT&limit=20")
    except Exception:
        b = _get(f"https://api.exchange.coinbase.com/products/{sym}-USD/book?level=2")
    agg = lambda rows: [[float(p), float(q)] for p, q, *_ in rows[:12]]
    return {"bids": agg(b["bids"]), "asks": agg(b["asks"]), "simulated": False}

# ---------- acciones (yfinance) ----------
def _yf_hist(sym):
    import yfinance as yf
    d = yf.Ticker(sym).history(period="5d", interval="5m", prepost=True)
    return [(int(t.timestamp()), float(r.High), float(r.Low), float(r.Close), float(r.Volume)) for t, r in d.iterrows()][-300:]

def candles(sym):
    """Lista de (ts, high, low, close, vol) en velas de 5 min."""
    if sym in CRYPTO: return _cached("c"+sym, 60, lambda: _crypto_candles(sym))
    return _cached("c"+sym, 120, lambda: _yf_hist(sym))

def price(sym):
    if sym in CRYPTO: return _cached("p"+sym, 3, lambda: _crypto_price(sym))
    def f():
        import yfinance as yf
        fi = yf.Ticker(sym).fast_info
        return float(fi["last_price"])
    p = _cached("p"+sym, 30, f)
    if p is None:
        c = candles(sym); p = c[-1][3] if c else None
    return p

def book(sym):
    if sym in CRYPTO:
        b = _cached("b"+sym, 2, lambda: _crypto_book(sym))
        if b: return b
    p = price(sym)  # libro simulado alrededor del precio
    if not p: return {"bids": [], "asks": [], "simulated": True}
    import random
    step = p * 0.0002
    return {"bids": [[p - step*(i+1), random.uniform(1, 30)] for i in range(12)],
            "asks": [[p + step*(i+1), random.uniform(1, 30)] for i in range(12)], "simulated": True}

def fear_greed():
    return _cached("fng", 1800, lambda: int(_get("https://api.alternative.me/fng/?limit=1")["data"][0]["value"])) or 50
