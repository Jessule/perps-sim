#!/usr/bin/env bash
# Vigilante 24/7: reinicia la app y el túnel cloudflared si caen, y reescribe public_url.txt.
cd "$(dirname "$0")"; D=$(pwd); CF=$(command -v cloudflared || echo ~/.local/bin/cloudflared)
mkdir -p logs; APP=""; TUN=""
start_app(){ HOST=127.0.0.1 nohup python3 run.py >> logs/app.log 2>&1 & APP=$!; echo "$(date) app pid $APP" >> logs/watchdog.log; }
start_tun(){ : > logs/tunnel.log; nohup "$CF" tunnel --no-autoupdate --protocol http2 --url http://127.0.0.1:8000 >> logs/tunnel.log 2>&1 & TUN=$!
  for i in $(seq 1 60); do U=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' logs/tunnel.log | head -1); [ -n "$U" ] && break; sleep 1; done
  [ -n "$U" ] && echo "$U/?k=$(cat .token)" > public_url.txt
  echo "$(date) tunnel pid $TUN url $U" >> logs/watchdog.log; }
pkill -f "python3 run.py"; pkill -f "cloudflared tunnel"; sleep 1
start_app; sleep 4; start_tun; FAILS=0
while true; do
  sleep 15
  if ! kill -0 $APP 2>/dev/null || ! curl -sf -m 10 -o /dev/null http://127.0.0.1:8000/static/icon-192.png; then
    echo "$(date) app caída, reinicio" >> logs/watchdog.log; kill $APP 2>/dev/null; start_app; fi
  if ! kill -0 $TUN 2>/dev/null; then echo "$(date) túnel caído, reinicio" >> logs/watchdog.log; start_tun; FAILS=0; continue; fi
  U=$(cut -d/ -f1-3 public_url.txt 2>/dev/null)
  if [ -n "$U" ] && ! curl -sf -m 15 -o /dev/null "$U/static/icon-192.png"; then FAILS=$((FAILS+1)); else FAILS=0; fi
  if [ $FAILS -ge 8 ]; then echo "$(date) URL pública no responde, reinicio túnel" >> logs/watchdog.log; kill $TUN; sleep 2; start_tun; FAILS=0; fi
done
