"""Arranca la app: python run.py  → http://localhost:8000 (o http://<IP-del-PC>:8000 desde el móvil)."""
import os, socket
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn, data, engine

app = FastAPI(title="Grok Bot PERPS (simulado)")
BASE = os.path.dirname(os.path.abspath(__file__)); ST = os.path.join(BASE, "static")
import secrets, hmac
from fastapi import Request
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse
TOKEN_FILE = os.path.join(BASE, ".token")
if os.environ.get("APP_TOKEN"): TOKEN = os.environ["APP_TOKEN"]
elif os.path.exists(TOKEN_FILE): TOKEN = open(TOKEN_FILE).read().strip()
else:
    TOKEN = secrets.token_urlsafe(18); open(TOKEN_FILE, "w").write(TOKEN)
PUBLIC = ("/static/icon-192.png", "/static/icon-512.png")

@app.middleware("http")
async def auth(request: Request, call_next):
    k = request.query_params.get("k"); c = request.cookies.get("k")
    ok = (k and hmac.compare_digest(k, TOKEN)) or (c and hmac.compare_digest(c, TOKEN))
    if not ok and request.url.path not in PUBLIC:
        if request.url.path.startswith("/api/"): return JSONResponse({"error": "no autorizado"}, 401)
        return HTMLResponse("<h3 style='font-family:sans-serif'>Acceso restringido. Abre el enlace con tu clave.</h3>", 401)
    if k and request.method == "GET" and not request.url.path.startswith("/api/"):
        if request.url.path == "/":  # guarda la cookie y quita la clave de la barra de direcciones
            r = RedirectResponse("/", 302)
        else: r = await call_next(request)
        r.set_cookie("k", TOKEN, max_age=10*365*86400, httponly=True, secure=request.headers.get("x-forwarded-proto", request.url.scheme) == "https", samesite="lax")
        return r
    return await call_next(request)

@app.on_event("startup")
def _s(): engine.start()

@app.get("/api/state")
def state():
    with engine.LOCK:
        S = engine.S; fx = data.eurusd()
        pos = []
        for p in S["positions"]:
            px = p["hist"][-1]; u = engine.upnl(p, px)
            pos.append({**p, "px": px, "upnl": u, "upct": u/p["margin"]*100})
        return {"fx": fx, "equity": engine.equity(), "start": S["start_usd"], "cash": S["cash"], "positions": pos,
                "settled": S["settled"][:30], "feed": S["feed"][:80], "pending": S["pending"],
                "equity_hist": S["equity_hist"][-120:], "assets": data.ASSETS, "stocks": data.STOCKS}

@app.get("/api/book/{sym}")
def book(sym: str):
    sym = sym.upper()
    if sym not in data.ASSETS: return {"error": "activo desconocido"}
    b = data.book(sym); p = data.price(sym); c = data.candles(sym) or []
    ch = (p/c[-min(len(c),288)][3]-1)*100 if c and p else 0
    return {"sym": sym, "price": p, "ch24": ch, **b}

@app.post("/api/reset")
def reset(): engine.reset(); return {"ok": True}

app.mount("/static", StaticFiles(directory=ST), name="static")
@app.get("/")
def index(): return FileResponse(os.path.join(ST, "index.html"))
@app.get("/sw.js")
def sw(): return FileResponse(os.path.join(ST, "sw.js"), media_type="application/javascript")
@app.get("/manifest.webmanifest")
def mf():
    import json as _j
    m = _j.load(open(os.path.join(ST, "manifest.webmanifest"))); m["start_url"] = f"/?k={TOKEN}"
    return JSONResponse(m, media_type="application/manifest+json")

if __name__ == "__main__":
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close()
    except Exception: ip = "TU-IP"
    port = int(os.environ.get("PORT", 8000))
    print(f"\n  PC:    http://localhost:{port}\n  Móvil: http://{ip}:{port}  (misma Wi-Fi)\n")
    uvicorn.run(app, host=os.environ.get("HOST", "0.0.0.0"), port=port, log_level="warning")
