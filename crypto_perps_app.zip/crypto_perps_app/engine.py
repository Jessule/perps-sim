"""Motor de paper trading de perpetuos SIMULADOS. Nunca toca dinero real ni Trading 212."""
import json, os, time, threading, uuid
import data, agents as A
FEE = 0.005; MMR = 0.005; SLOTS = 4; START_EUR = 5000.0
STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "state.json")
LOCK = threading.RLock()

def now(): return time.time()

import subprocess
NOTIFY = "/workspace/mat/discord_notify.py"
def notify(text):
    """Envía a Discord en segundo plano sin bloquear el motor ni imprimir el webhook."""
    if not os.environ.get("DISCORD_WEBHOOK_URL") or not os.path.exists(NOTIFY): return
    def _go():
        try: subprocess.run(["python3", NOTIFY, "[PERPS SIM] " + text], timeout=30, capture_output=True)
        except Exception: pass
    threading.Thread(target=_go, daemon=True).start()

def eur(usd, d=2):
    fx = data.eurusd(); f = lambda v: f"{v:,.{d}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"{f(usd/fx)} € ({f(usd)} $)"
def seur(usd): return ("+" if usd >= 0 else "−") + eur(abs(usd))

def new_state():
    fx = data.eurusd()
    return {"start_usd": START_EUR*fx, "cash": START_EUR*fx, "positions": [], "settled": [], "feed": [],
            "equity_hist": [], "created": now(), "pending": {}}

def load():
    try:
        with open(STATE_FILE) as f: return json.load(f)
    except Exception: return new_state()

S = load()
def save():
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f: json.dump(S, f)
    os.replace(tmp, STATE_FILE)

def feed(agent, sym, msg, kind="info"):
    S["feed"].insert(0, {"t": now(), "agent": agent, "sym": sym, "msg": msg, "kind": kind})
    del S["feed"][300:]

def upnl(p, px):
    d = 1 if p["side"] == "LONG" else -1
    return d * (px - p["entry"]) * p["qty"]

def equity():
    eq = S["cash"]
    for p in S["positions"]:
        px = p["hist"][-1] if p["hist"] else p["entry"]
        eq += max(0, p["margin"] + upnl(p, px))
    return eq

def liq_price(side, entry, lev):
    return entry*(1 - 1/lev + MMR) if side == "LONG" else entry*(1 + 1/lev - MMR)

def close(p, px, reason):
    S["positions"].remove(p)
    if reason == "LIQUIDACIÓN":
        pnl = -p["margin"]; fee = 0.0; ret = 0.0
    else:
        fee = abs(px*p["qty"])*FEE
        pnl = upnl(p, px) - fee
        ret = max(0.0, p["margin"] + pnl)
        pnl = ret - p["margin"]
    S["cash"] += ret
    total = pnl - p["fee_in"]
    S["settled"].insert(0, {**{k: p[k] for k in ("id","sym","side","lev","entry","margin","notional","opened")},
        "exit": px, "pnl": total, "pct": total/p["margin"]*100, "reason": reason, "closed": now(), "fees": p["fee_in"]+fee})
    del S["settled"][100:]
    tag = "💥 LIQUIDACIÓN" if reason == "LIQUIDACIÓN" else ("✅ CIERRE" if total >= 0 else "🔻 CIERRE")
    notify(f"{tag} {p['sym']} {p['side']} {p['lev']}x · margen {eur(p['margin'])} · entrada {p['entry']:.6g} → salida {px:.6g}\n"
           f"PnL neto {seur(total)} ({total/p['margin']*100:+.1f}%) · motivo: {reason} · comisiones {eur(p['fee_in']+fee)}")
    feed("Chief", p["sym"], f"CIERRE {p['side']} {p['lev']}x por {reason} a {px:.4g} · PnL neto {total:+.2f} $ (comisiones incluidas)",
         "loss" if total < 0 else "win")

def manage():
    for p in list(S["positions"]):
        px = data.price(p["sym"])
        if not px: continue
        p["hist"].append(px); del p["hist"][:-80]
        L = p["side"] == "LONG"
        if (L and px <= p["liq"]) or (not L and px >= p["liq"]): close(p, p["liq"], "LIQUIDACIÓN")
        elif (L and px <= p["sl"]) or (not L and px >= p["sl"]): close(p, px, "STOP")
        elif (L and px >= p["tp"]) or (not L and px <= p["tp"]): close(p, px, "TAKE PROFIT")
        elif now() - p["opened"] > 8*3600: close(p, px, "TIEMPO (8h)")

def evaluate(sym):
    stock = sym in data.STOCKS
    c = data.candles(sym); px = data.price(sym)
    if not c or len(c) < 60 or not px: return
    i = A.indicators(c, px)
    strong, side, m = A.scout(i, stock)
    pend = S["pending"].get(sym)
    if pend and now() - pend["t"] > 3*3600: S["pending"].pop(sym); pend = None
    if any(p["sym"] == sym for p in S["positions"]): return
    last = S.setdefault("last_eval", {}).get(sym, 0)
    if not pend and now() - last < 900: return  # 15 min de enfriamiento por activo para no repetir análisis
    if pend:  # Chief espera retroceso (anti-FOMO)
        side = pend["side"]
        pulled = (px <= pend["entry_max"]) if side == "LONG" else (px >= pend["entry_min"])
        if not pulled: return
        S["pending"].pop(sym)
        feed("Chief", sym, f"Llegó el retroceso a {px:.4g}; reevalúo la entrada {side}", "info")
    elif not strong: return
    else: feed("Scout", sym, m, "signal")
    S["last_eval"][sym] = now()
    ns, nm = A.news(i, side, stock); feed("News", sym, nm)
    ss, sm = (A.sentiment(i, data.fear_greed(), side) if not stock else
              A.sentiment(i, max(0, min(100, 50 + int(i["ret24"]*500))), side, "Momentum-sentiment acción")); feed("Sentiment", sym, sm)
    ch, cm = A.charts(i, side); feed("Charts", sym, cm)
    risk, fomo, km = A.skeptic(i, side, ch, ns, ss, stock); feed("Skeptic", sym, km, "veto" if risk >= 8 else "info")
    if fomo and not pend:
        tgt = i["sma20"] + (1 if side == "LONG" else -1)*0.5*i["atr"]
        S["pending"][sym] = {"t": now(), "side": side, "entry_max": tgt, "entry_min": tgt}
        feed("Chief", sym, f"No persigo el movimiento: espero retroceso hasta {tgt:.4g} (media20 ± 0.5 ATR) para {side}", "wait"); return
    if risk >= 8: feed("Chief", sym, "Respeto el veto de Skeptic. NO TRADE.", "veto"); return
    if ch["rr"] < 1.5: feed("Chief", sym, "R/R insuficiente. NO TRADE."); return
    if any(p["sym"] == sym for p in S["positions"]): feed("Chief", sym, "Ya hay posición abierta en este activo."); return
    if len(S["positions"]) >= SLOTS: feed("Chief", sym, "Las 4 partes del capital están en uso. NO TRADE."); return
    eq = equity(); margin = eq/SLOTS; note = "1/4 del capital"
    if 6 <= risk <= 7: margin /= 2; note = "1/8 del capital (riesgo 6-7 → mitad)"
    margin = min(margin, S["cash"]*0.95)
    if margin < 10: feed("Chief", sym, "Sin efectivo suficiente."); return
    conviction = max(0.05, min(1, 0.35 + 0.15*ns + 0.15*ss + (0.15 if ch["trend_ok"] else -0.15) + 0.05*(ch["rr"]-2) + (0.1 if i["volr"] > 2 else 0)))
    stop_pct = abs(px - ch["sl"])/px
    lev, lw = A.chief_leverage(risk, conviction, stop_pct)
    notional = margin*lev
    # la comisión de entrada (0,5% del nocional) sale del margen asignado
    fee_in = notional*FEE
    if fee_in >= margin*0.5:
        lev = max(1, int(margin*0.5/ (margin*FEE)) // 1); notional = margin*lev; fee_in = notional*FEE
    S["cash"] -= margin + fee_in
    p = {"id": uuid.uuid4().hex[:8], "sym": sym, "side": side, "lev": lev, "entry": px, "qty": notional/px,
         "margin": margin, "notional": notional, "fee_in": fee_in, "sl": ch["sl"], "tp": ch["tp"],
         "liq": liq_price(side, px, lev), "risk": risk, "opened": now(), "hist": [px]}
    S["positions"].append(p)
    fx = data.eurusd()
    notify(f"🟢 APERTURA {sym} {side} {lev}x · margen {eur(margin)} · nocional {eur(notional)} · entrada {px:.6g}\n"
           f"SL {p['sl']:.6g} · TP {p['tp']:.6g} · liquidación {p['liq']:.6g} · riesgo {risk}/10\nMotivo: {note}; apalancamiento: {lw}")
    feed("Chief", sym, f"ABRO {side} {lev}x · margen {margin/fx:.0f} € ({margin:.0f} $), nocional {notional:.0f} $, {note}. "
         f"Apalancamiento: {lw}. Liq {p['liq']:.4g}, SL {p['sl']:.4g}, TP {p['tp']:.4g}. Comisión entrada {fee_in:.2f} $", "trade")

def loop():
    feed("Chief", "-", "Motor arrancado (cuenta SIMULADA).")
    while True:
        try:
            with LOCK:
                manage()
                for sym in data.ASSETS:
                    try: evaluate(sym)
                    except Exception as e: feed("Sistema", sym, f"error datos: {e}", "err")
                manage()
                if now() - S.get("last_summary", 0) >= 6*3600:
                    S["last_summary"] = now(); summary()
                S["equity_hist"].append([now(), equity()]); del S["equity_hist"][:-500]
                save()
        except Exception as e:
            print("loop error", e)
        time.sleep(20)

def summary():
    eq = equity(); g = eq - S["start_usd"]
    lines = [f"📊 RESUMEN 6h · cartera {eur(eq)} · resultado {seur(g)} ({g/S['start_usd']*100:+.2f}%) · libre {eur(S['cash'])}"]
    for p in S["positions"]:
        px = p["hist"][-1]; u = upnl(p, px)
        lines.append(f"• {p['sym']} {p['side']} {p['lev']}x · margen {eur(p['margin'])} · {p['entry']:.6g}→{px:.6g} · PnL {seur(u)} ({u/p['margin']*100:+.1f}%)")
    if not S["positions"]: lines.append("• Sin posiciones abiertas")
    rec = [t for t in S["settled"] if now() - t["closed"] < 6*3600]
    lines.append(f"Cerradas en 6h: {len(rec)} · PnL {seur(sum(t['pnl'] for t in rec))}")
    if S["pending"]: lines.append("Esperando retroceso: " + ", ".join(S["pending"]))
    notify("\n".join(lines))

def start():
    threading.Thread(target=loop, daemon=True).start()

def reset():
    global S
    with LOCK:
        S.clear(); S.update(new_state()); feed("Chief", "-", "Cuenta reiniciada a 5.000 €."); save()
